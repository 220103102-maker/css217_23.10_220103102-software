# Facade Pattern Lab Task

Java implementation of the Facade Design Pattern for an airline booking workflow.

## Requirements
- Java 21 (or a compatible modern JDK)
- No external dependencies

## Files
- `FlightBookingFacade.java` — single entry point that coordinates all subsystems.
- `Main.java` — runs four test scenarios.
- The other five `.java` files are the provided subsystem classes from the lab specification.

## Run
From this directory:

```bash
javac *.java
java Main
```

## Test scenarios
1. Successful standard booking.
2. Blocked seat in row 13.
3. Invalid card number and automatic seat-lock rollback.
4. SILVER loyalty member: baggage engine is skipped and the 10% promo is applied.

The 8-parameter `bookFlight` overload remains backward-compatible and defaults to `STANDARD`.
